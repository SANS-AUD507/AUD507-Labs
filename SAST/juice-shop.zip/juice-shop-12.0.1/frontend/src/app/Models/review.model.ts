/*
 * Copyright (c) 2014-2020 Bjoern Kimminich.
 * SPDX-License-Identifier: MIT
 */

export interface Review {
  _id: string
  message: string
  author: string
}
