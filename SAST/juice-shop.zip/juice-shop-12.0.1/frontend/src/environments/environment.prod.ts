/*
 * Copyright (c) 2014-2020 Bjoern Kimminich.
 * SPDX-License-Identifier: MIT
 */

export const environment = {
  production: true,
  hostServer: '.'
}
